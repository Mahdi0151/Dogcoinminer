# XMR Research Miner - راهنمای فارسی

ماینر واقعی مونرو برای اندروید، بر پایه XMRig. برای استفاده آموزشی و پژوهشی.

## ساختار پروژه

- `app/src/main/java/com/research/xmrminer/MainActivity.kt` : رابط کاربری، ورودی استخر و کیف پول، نمایش وضعیت
- `app/src/main/java/com/research/xmrminer/MiningService.kt` : سرویس پیش‌زمینه که باینری xmrig را اجرا می‌کند
- `app/src/main/res/layout/activity_main.xml` : چیدمان صفحه
- `scripts/build-xmrig-android.sh` : کراس‌کامپایل XMRig برای arm64

## مراحل ساخت

1. **کامپایل XMRig** (روی کامپیوتر لینوکس/مک/ویندوز+WSL):
   ```bash
   export NDK_PATH=~/Android/Sdk/ndk/26.3.11579264   # مسیر NDK خودت
   ./scripts/build-xmrig-android.sh
   ```
   باینری خروجی را در `app/src/main/assets/xmrig` کپی کن.

2. **باز کردن پروژه**: پوشه را در Android Studio باز کن (JDK 17 لازم است).

3. **بیلد APK**: از منوی Build گزینه Build APK(s) را بزن. خروجی در
   `app/build/outputs/apk/debug/app-debug.apk`

4. **نصب روی گوشی**: فایل APK را منتقل و نصب کن (اجازه نصب از منابع ناشناس لازم است).

## نکات مهم

- فقط معماری arm64 پشتیبانی می‌شود (بیشتر گوشی‌های مدرن).
- درآمد روی گوشی تقریباً صفر است؛ این ابزار برای یادگیری است.
- استفاده طولانی گوشی را داغ و باتری را مصرف می‌کند.
- برخی استخرها برای ولت جدید حداقل درآمد پرداخت دارند.
- Android 14 سرویس‌های foreground را سخت‌گیرانه‌تر اجرا می‌کند؛ اعلان باید فعال باشد.
