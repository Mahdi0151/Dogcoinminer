package com.research.xmrminer

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import java.io.File

class MainActivity : AppCompatActivity() {

    private val pools = listOf(
        "pool.hashvault.pro:80",
        "pool.supportxmr.com:3333",
        "xmrpool.eu:3333",
        "pool.minexmr.com:4444"
    )
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var statusText: TextView
    private lateinit var hashrateText: TextView
    private lateinit var sharesText: TextView
    private lateinit var elapsedText: TextView
    private lateinit var startBtn: MaterialButton
    private lateinit var stopBtn: MaterialButton

    private val ticker = object : Runnable {
        override fun run() {
            refreshStats()
            handler.postDelayed(this, 2000)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val poolInput = findViewById<AutoCompleteTextView>(R.id.poolInput)
        poolInput.setAdapter(ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, pools))
        poolInput.setText(pools.first(), false)

        val walletInput = findViewById<EditText>(R.id.walletInput)
        val threadsInput = findViewById<EditText>(R.id.threadsInput)
        threadsInput.setText("2")

        statusText = findViewById(R.id.statusText)
        hashrateText = findViewById(R.id.hashrateText)
        sharesText = findViewById(R.id.sharesText)
        elapsedText = findViewById(R.id.elapsedText)
        startBtn = findViewById(R.id.startBtn)
        stopBtn = findViewById(R.id.stopBtn)

        restoreInputs(poolInput, walletInput, threadsInput)

        startBtn.setOnClickListener {
            val pool = poolInput.text.toString().trim()
            val wallet = walletInput.text.toString().trim()
            val threads = threadsInput.text.toString().toIntOrNull() ?: 2
            if (pool.isBlank()) { toast("Pool URL is required"); return@setOnClickListener }
            saveInputs(pool, wallet, threads)
            requestNotificationPermission {
                installBinaryIfNeeded {
                    val i = Intent(this, MiningService::class.java)
                        .setAction(MiningService.ACTION_START)
                        .putExtra(MiningService.EXTRA_POOL, pool)
                        .putExtra(MiningService.EXTRA_WALLET, wallet)
                        .putExtra(MiningService.EXTRA_THREADS, threads)
                    ContextCompat.startForegroundService(this, i)
                    startPolling()
                }
            }
        }

        stopBtn.setOnClickListener {
            stopService(Intent(this, MiningService::class.java).setAction(MiningService.ACTION_STOP))
            statusText.text = "stopped"
        }

        if (isServiceRunning()) startPolling()
    }

    private fun isServiceRunning(): Boolean {
        // If the service wrote status=running, treat it as running after process death restarts.
        return try {
            File(filesDir, "state/status").readText().trim() == "running"
        } catch (_: Exception) { false }
    }

    private fun restoreInputs(pool: AutoCompleteTextView, wallet: EditText, threads: EditText) {
        val p = getSharedPreferences("cfg", MODE_PRIVATE)
        p.getString("pool", null)?.let { pool.setText(it, false) }
        p.getString("wallet", null)?.let { wallet.setText(it) }
        p.getInt("threads", 2).let { threads.setText(it.toString()) }
    }

    private fun saveInputs(pool: String, wallet: String, threads: Int) {
        getSharedPreferences("cfg", MODE_PRIVATE).edit()
            .putString("pool", pool)
            .putString("wallet", wallet)
            .putInt("threads", threads)
            .apply()
    }

    private fun installBinaryIfNeeded(onReady: () -> Unit) {
        val bin = File(filesDir, "xmrig")
        if (bin.exists() && bin.canExecute()) { onReady(); return }
        Thread {
            try {
                assets.open("xmrig").use { input ->
                    FileOutputStream(bin).use { output -> input.copyTo(output) }
                }
                bin.setExecutable(true, true)
                runOnUiThread { onReady() }
            } catch (e: Exception) {
                runOnUiThread { toast("Failed to install binary: ${e.message}") }
            }
        }.start()
    }

    private fun startPolling() {
        statusText.text = "running"
        handler.removeCallbacks(ticker)
        handler.post(ticker)
    }

    private fun refreshStats() {
        val dir = File(filesDir, "state")
        fun read(k: String) = try { File(dir, k).readText().trim() } catch (_: Exception) { "" }
        statusText.text = read("status").ifBlank { "idle" }
        hashrateText.text = "${read("hashrate")} H/s"
        sharesText.text = "accepted: ${read("accepted")}   rejected: ${read("rejected")}"
        if (read("status") == "running") startPollingIdle()
    }

    private var lastElapsedBase = 0L
    private fun startPollingIdle() {
        if (lastElapsedBase == 0L) lastElapsedBase = System.currentTimeMillis()
        elapsedText.text = "elapsed: ${((System.currentTimeMillis() - lastElapsedBase) / 1000)}s"
    }

    private fun requestNotificationPermission(onDone: () -> Unit) {
        if (Build.VERSION.SDK_INT < 33) { onDone(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            == PackageManager.PERMISSION_GRANTED) { onDone(); return }
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        // Continue regardless; mining works without the notification permission on most builds.
        onDone()
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
}
