package com.research.xmrminer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.FileObserver
import android.os.IBinder
import android.os.PowerManager
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Foreground service that runs the bundled xmrig binary for ARM64 Android.
 * State is exported to files under filesDir/state so the UI can poll cheaply.
 */
class MiningService : Service() {

    companion object {
        const val CHANNEL_ID = "mining"
        const val EXTRA_POOL = "pool"
        const val EXTRA_WALLET = "wallet"
        const val EXTRA_THREADS = "threads"
        const val ACTION_START = "com.research.xmrminer.START"
        const val ACTION_STOP = "com.research.xmrminer.STOP"
        const val STATE_DIR = "state"
    }

    private var process: Process? = null
    private val running = AtomicBoolean(false)
    private var logObserver: FileObserver? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val startedAt = System.currentTimeMillis()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> { stopMining(); stopSelf(); return START_NOT_STICKY }
            ACTION_START, null -> startMining(
                intent?.getStringExtra(EXTRA_POOL) ?: "pool.hashvault.pro:80",
                intent?.getStringExtra(EXTRA_WALLET) ?: "",
                intent?.getIntExtra(EXTRA_THREADS, 2) ?: 2
            )
        }
        return START_STICKY
    }

    private fun startMining(pool: String, wallet: String, threads: Int) {
        if (running.get()) return

        val bin = File(filesDir, "xmrig")
        require(bin.exists() && bin.canExecute()) { "xmrig binary not installed" }

        writeState("status", "starting")
        writeState("pool", pool)
        writeState("hashrate", "0.0")
        writeState("accepted", "0")
        writeState("rejected", "0")

        // xmrig reads the wallet from -u, pool from -o. -B prints plain logs (no ANSI).
        val pb = ProcessBuilder(
            bin.absolutePath,
            "-o", pool,
            "-u", wallet.ifBlank { "44test" },
            "-p", "android",
            "--donate-level=1",
            "--print-time=10",
            "--threads=$threads",
            "-B"
        ).redirectErrorStream(true)

        val logFile = File(filesDir, "xmrig.log")
        if (logFile.exists()) logFile.delete()
        pb.redirectOutput(logFile)

        try {
            process = pb.start()
        } catch (e: Exception) {
            writeState("status", "error: ${e.message}")
            return
        }

        running.set(true)
        writeState("status", "running")
        holdWakeLock()

        val fm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        startForeground(1, buildNotification(fm, "starting..."))

        watchLog(logFile, fm)
        spawnProcessWatcher()
    }

    private fun spawnProcessWatcher() {
        Thread {
            val p = process
            try { p?.waitFor() } catch (_: InterruptedException) {}
            if (running.getAndSet(false)) {
                // unexpected exit
                writeState("status", "stopped")
                stopSelf()
            }
        }.start()
    }

    private fun watchLog(logFile: File, fm: NotificationManager) {
        // FileObserver needs a directory; watch the filesDir and filter on the log name.
        val dir = filesDir
        logObserver = object : FileObserver(dir, FileObserver.MODIFY or FileObserver.CLOSE_WRITE) {
            override fun onEvent(event: Int, path: String?) {
                if (path != "xmrig.log") return
                if (!running.get()) return
                val text = try { logFile.readText().takeLast(8192) } catch (_: Exception) { return }
                parseStats(text)
                fm.notify(1, buildNotification(fm, summary()))
            }
        }
        logObserver?.startWatching()
    }

    private fun parseStats(text: String) {
        // Typical lines:
        // "... speed 10s/60s/15m 120.3 118.7 115.2 H/s max ..."
        // "... accepted (1/0) diff 50000 (145 ms)"
        val speed = Regex("""speed 10s/60s/15m ([\d.]+) ([\d.]+) ([\d.]+) H/s""")
            .findAll(text).lastOrNull()?.groupValues
        if (speed != null) writeState("hashrate", speed[1])
        val acc = Regex("""accepted \((\d+)/(\d+)\)""").findAll(text).lastOrNull()?.groupValues
        if (acc != null) {
            writeState("accepted", acc[1])
            writeState("rejected", acc[2])
        }
        if (text.contains("error") or text.contains("failed to connect")) {
            writeState("last_error", extractLine(text, "error"))
        }
    }

    private fun extractLine(text: String, needle: String): String =
        text.lines().lastOrNull { it.contains(needle, ignoreCase = true) }?.take(200) ?: ""

    private fun summary(): String {
        val hr = readState("hashrate") ?: "0.0"
        val acc = readState("accepted") ?: "0"
        return "$hr H/s | shares: $acc"
    }

    private fun buildNotification(fm: NotificationManager, text: String): Notification {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, getString(R.string.channel_name),
                NotificationManager.IMPORTANCE_LOW)
            fm.createNotificationChannel(ch)
        }
        val n = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle(getString(R.string.notification_title))
            .setContentText(text)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(true)
        return n.build()
    }

    private fun holdWakeLock() {
        wakeLock = (getSystemService(Context.POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "XMRMiner::lock")
        wakeLock?.acquire(10 * 60 * 60 * 1000L)
    }

    private fun stopMining() {
        running.set(false)
        logObserver?.stopWatching()
        wakeLock?.release()
        process?.destroy()
        process = null
        writeState("status", "stopped")
    }

    override fun onDestroy() {
        stopMining()
        super.onDestroy()
    }

    private fun stateDir(): File = File(filesDir, STATE_DIR).apply { mkdirs() }

    private fun writeState(key: String, value: String) {
        try { File(stateDir(), key).writeText(value) } catch (_: Exception) {}
    }

    private fun readState(key: String): String? = try { File(stateDir(), key).readText() } catch (_: Exception) { null }
}
