Place xmrig arm64 binary at app/src/main/assets/xmrig before building.
