#!/usr/bin/env bash
# Cross-compile XMRig for Android arm64 using the NDK.
# Requirements on your PC: Android NDK r26+, cmake >= 3.14, git.
set -euo pipefail

NDK=${NDK_PATH:?set NDK_PATH to your NDK root, e.g. ~/Android/Sdk/ndk/26.3.11579264}
API=26
ARCH=arm64
CC=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android$API-clang
CXX=$NDK/toolchains/llvm/prebuilt/linux-x86_64/bin/aarch64-linux-android$API-clang++
OUT=$(pwd)/xmrig-android-arm64

git clone https://github.com/xmrig/xmrig.git || true
cd xmrig
mkdir -p build && cd build
cmake .. \
  -DCMAKE_TOOLCHAIN_FILE=$NDK/build/cmake/android.toolchain.cmake \
  -DANDROID_ABI=$ARCH \
  -DANDROID_PLATFORM=android-$API \
  -DCMAKE_BUILD_TYPE=Release \
  -DWITH_OPENCL=OFF \
  -DWITH_CUDA=OFF \
  -DWITH_TLS=OFF \
  -DBUILD_STATIC=ON
make -j$(nproc)

# Static build produces a single self-contained binary; strip and copy it out.
ls *.so >/dev/null 2>&1 && cp libxmrig.so $OUT || cp xmrig $OUT
echo "Binary at: $OUT"
echo "Copy it into app/src/main/assets/xmrig"
